
Write-Host "Starting up the HDB process on port 5012..."

# Checking if sample hdb exists
If ( Test-Path "C:\neueda_q\q\sample_hdb" ) {
	Start-Sleep -s 3
	Start-Process "C:\neueda_q\q\w32\q" -ArgumentList "C:\neueda_q\q\sample_hdb", "-p 5012" -WindowStyle Hidden
} else {
	Write-Host "sample HDB does not exist, check if q has been installed already and if the buildhdb.q script has been run..."
	Write-Host "exiting..."
	Start-Sleep -s 5
	exit
}


Write-Host "Opening the QPad IDE to begin quering the HDB..."

# Open the Qpad IDE
If ( Test-Path "C:\neueda_q\qpad" ) {
	Start-Sleep -s 2
	Write-Host "Remember to connect to the HDB first on the 5012 port..."
	Start-Sleep -s 5
	If ( Test-Path "C:\neueda_q\qpad\qpad.exe" ) {
		. "C:\neueda_q\qpad\qpad.exe"
	} elseif ( Test-Path "C:\neueda_q\qpad\qpad64.exe" ){
		. "C:\neueda_q\qpad\qpad64.exe"
	} else {
		"There is an issue with QPad, check where Qpad installed, it may need to be installed again..."
		Start-Sleep -s 5
}
} else {
	Write-Host "Qpad does not appear to be installed, check if QPad has been downloaded, or is located in a different folder than C:\neueda_q\"
	Write-Host "exiting..."
	Start-Sleep -s 8
	exit
}


