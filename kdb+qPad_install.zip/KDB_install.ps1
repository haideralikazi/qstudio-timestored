
function download_q 
{
Write-Host "Downloading q..."
& 'curl' -Uri https://kx.com/347_d0szre-fr8917_llrsT4Yle-5839sdX/3.6/windows.zip -Outfile C:\Users\$env:UserName\Downloads\windows.zip 
Start-Sleep -s 2
# Unzip the download into neueda_q dirctory - this will create that folder automatically 
Expand-Archive C:\Users\$env:UserName\Downloads\windows.zip -DestinationPath C:\neueda_q\
# Must set QHOME as it q is not in the default C:\q 
$Env:QHOME = "C:\neueda_q\q"
}


# Checking if q has been installed already
If ( Test-Path "C:\neueda_q\q" ) {
	Write-Host "It appears q has been installed already, do you want to overwrite (Y/N)?"
	$response = read-host
	if ( $response -eq "Y" ) {
		Remove-Item C:\neueda_q\q -Force -Recurse
		download_q
	}	
} else {
	download_q
}
	
	
function download_qpad
{
Write-Host "Downloading QPad..."

# QPad requires the below to be install 
# Checks if it is installed already prior to downloading & installing
Write-Host "Checking if dependent software for QPad is installed..."
Start-Sleep -s 2
$software = "Microsoft Visual C+\+"
$installed = ((gp HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*).DisplayName -Match $software).Length -gt 0
If(-Not $installed) {
	Write-Host "'$software' is NOT installed"
	Write-Host "Downloading now..."
	& 'curl' -Uri https://download.microsoft.com/download/5/B/C/5BC5DBB3-652D-4DCE-B14A-475AB85EEF6E/vcredist_x86.exe -UseBasicParsing -Outfile C:\Users\$env:UserName\Downloads\vcredist_x86.exe
	Write-Host "Please follow default prompts to install..."
	. "C:\Users\$env:UserName\Downloads\vcredist_x86.exe"
	Write-Host "Once you have installed $software , Press any key to continue..."
	$Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
} else {
	Write-Host "'$software' is installed already, Press any key to continue..."
	$Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
# downloading qpad
$downloadPath = "http://www.qinsightpad.com/upload/qpad/"
$zip = (((Invoke-WebRequest -Uri $downloadPath).Links | Where-Object {$_.href -like "*x86.zip*"} ) )
$url = $downloadPath + $zip.href
& 'curl' -Uri $url -UseBasicParsing -Outfile C:\Users\$env:UserName\Downloads\qpad.zip
Start-Sleep -s 2
Expand-Archive C:\Users\$env:UserName\Downloads\qpad.zip -DestinationPath C:\neueda_q\qpad
}


# Check if qpad has been installed already
If ( Test-Path "C:\neueda_q\qpad" ) {
	Write-Host "It appears qpad has been installed already, do you want to overwrite (Y/N)?"
	$response = read-host
	if ( $response -eq "Y" ) {  
		Remove-Item C:\neueda_q\qpad -Force -Recurse
		download_qpad
	}
} else {
	download_qpad
}


# Check if the sample HDB already exists
Write-Host "Creating the sample HDB..."
If ( Test-Path "C:\neueda_q\q\sample_hdb" ) {
	Write-Host "HDB already exists..." 
} else {
	# Create the sample HDB using the build q script from the downloaded script
	Copy-Item -Path C:\Users\$env:UserName\Downloads\KDB+Install_setup\buildhdb.q -Destination C:\neueda_q\q
	cd C:\neueda_q\q
	Start-Process "C:\neueda_q\q\w32\q" -ArgumentList "C:\neueda_q\q\buildhdb.q" -WindowStyle Hidden
	Start-Sleep -s 5
}


Write-Host "Starting up the HDB process on port 5012..."
Start-Sleep -s 3
Start-Process "C:\neueda_q\q\w32\q" -ArgumentList "C:\neueda_q\q\sample_hdb", "-p 5012" -WindowStyle Hidden


Start-Sleep -s 3
If ( Test-Path "C:\Users\$env:UserName\Downloads\windows.zip" ) {
	Write-Host "Removing q downloaded zip from Downloads folder..."
	Start-Sleep -s 2
	Remove-Item C:\Users\$env:UserName\Downloads\windows.zip
}
If ( Test-Path "C:\Users\$env:UserName\Downloads\qpad.zip" ) {
	Write-Host "Removing qpad downloaded zip from Downloads folder..."
	Start-Sleep -s 2
	Remove-Item C:\Users\$env:UserName\Downloads\qpad.zip
}


# Open the Qpad IDE
Write-Host "Opening the QPad IDE to begin quering the HDB..."
Start-Sleep -s 2
Write-Host "Remember to connect to the HDB first on the 5012 port..."
Start-Sleep -s 5
If ( Test-Path "C:\neueda_q\qpad\qpad.exe" ) {
	. "C:\neueda_q\qpad\qpad.exe"
} elseif ( Test-Path "C:\neueda_q\qpad\qpad64.exe" ){
	. "C:\neueda_q\qpad\qpad64.exe"
} else {
	"There is an issue with QPad, check where Qpad installed, it may need to be installed again..."
	Start-Sleep -s 5
}