Extract KDB+Install_setup.zip to the default location -> C:\Users\$env:UserName\Downloads\

The following directory should then exist -> C:\Users\$env:UserName\Downloads\KDB+Install_setup

Click into the KDB+Install_setup folder

Right-click on KDB_install.ps1 & "Run with PowerShell"
# This will download 32-bit kdb+ 
# Download QPad
# Copy the buildkdb.q script into the q directory
# And run this script to create a sample HDB
# A HDB process will be started up in the background on port 5012
# QPad will be opened


QPad IDE will then open.
Follow the instruction in Initial_setup_instructions.docx to connect to the HDB via QPad

Note: the HDB process will continue to run in the background, run stop_hdb.ps1 when you want to kill it

Subsequent to the initial install steps, follow the instructions in Launch_HDB_&_QPad_instructions.docx to launch this environment at a later time.

** If you have encountered issues with the automated download and install of QPad please refer to Manual_QPad_install.docx **

