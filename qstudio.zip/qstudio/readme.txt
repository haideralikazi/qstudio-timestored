www.timestored.com/qStudio - an IDE for kdb+ database

We hope to make this the best IDE for q there can be 
so if you find a bug or feel there's a feature you would like added
please get in touch: tech@timestored.com

- Ryan Hamilton
___________________________________________________________________

Changelog:

2020-11-15 - 1.52   - Allow running on java 8/9/10/11.
					- Bugfix:DefaultDocumentEventUndoableWrapper error no longer thrown on java9. JSyntaxPane upgraded.
					- Bugfix:ExceptionInInitializerError no longer throws on startup, DockFrontend library upgraded.
					- Bugfix:UnsupportedDataTypeException was throw due to javax.bind removal in java 11+. Now bundled.
					- (sqlDashboards) Upgrade charting library to 1.0.19
					
2020-05-10 - 1.51   - jq added to bundle.

2019-12-30 - 1.50   - qDoc Add @example/@col support, decrease output verbosity, add baseHref support.

2019-08-01 - 1.49   - (sqlDashboards) SQL Array support, now displays nested numeric/date/time arrays.

2019-04-25 - 1.48   - Build using java 8. Note: This may no longer run on java 6 runtimes.
					- Allow license.txt specified in path.

2018-07-01 - 1.47   - bugfix to work in kdb 3.6 due to $[;;] parser change.
					- Copy web link to latest result button added.

2018-05-12 - 1.46   - Update to latest qunit with assertKnown and parameters.
				    - Fix step plot to auto size the axis rather than always start at zero.

2018-03-31 - 1.45   - Hidden folders/files regex fix.
					- Add Step-Plot Chart display option

2018-02-11 - 1.44   - Add Stacked Bar Chart display option
                    - Add Dot graph render display option (Inspired by Noormo)
                    - Bugfix: Mac was displaying startup error with java 9.
					- Bugfix: Ctrl+F Search in source fixed. (Thanks Alex)
					
2017-04-12 - 1.43   - Add Stack Trace reporting when user is using wrapped-queries and kdb 3.5+
                    - Bugfix: Mac "Save As" dialog was hiding the filename prompt. Fixed.
					
2017-02-05 - 1.42   - Bugfix Sending empty query would cause qStudio to get into bad state.
					- Default to chart NoRedraw when first loaded to save memory/time.
					- Preferences Improvements
						- Option to allow saving Document with windows \r\n or linux \n line endings. Settings -> Preferences... -> Misc
						- Allow specifying regex for folders that should be ignored by the "File Tree" window and Autocomplete
					- Add copy "hopen `:currentServer" command button to toolbar.
					- Ctrl+p Shortcut - Allow opening folders in explorer aswell as files.
					- Smarter Background Documents Saving (30 seconds between saves on background thread)
					- (sqlDashboards) Stop wrapping JDBC queries as we dont want kdb to use the standard SQL handler. We want to use the q) handler.
					- (sqlDashboards) Allow saving .das without username/password to allow sharing
										Prompt user on file open if cant connect to server.
					- (sqlDashboards) Bugfix: Allow resizing of windows within sqlDashboards even when "No table returned" or query contains error.
					- (sqlDashboards) If query is wrong and missing arg or something, report the reason.
					
2016-06-24 - 1.41   - Add ability to use custom Security Authentications and JDBC drivers
					  http://www.timestored.com/qstudio/help/kerberos-custom-security-authentication
					- Load .jar plugins from libs folder.
					- Remove ctrl+w shortcut as it was often getting used by mistake
					- Improved startup/shutdown logging.
                    
					
2016-02-15 - 1.40   - No need to save changes before shutdown, unsaved changes stored till reopened.
                    - Add sqlchart to system path.
					- Fix display of tables with underscore in the name.
                    - Database documenter/report enhancements
					- Improved code printing
					- FileTreePanel much more efficient at displaying large number of files.
					
2015-01-16 - 1.37	- Fix query cancelling
					- Number of fixes to help supporting 5000+ server connections:
						- Allow nested connection folders
						- Allow specifying default username/password once for all servers
						- Add critical color option
					- Fix critical Mac bug that prevented launching in some instances
					- Sort File Tree Alphabetically
					
2014-10-20 - 1.36	- Allow opening copies of charts, results and the console in a pop-out window
					- Increase size of serverlist supported (4000+)
					- Colored editor tabs
					- Bugfix to tooltips and specialised sync messaging

2014-10-15 - 1.35	- Added support for UTF-8 / Chinese Language
					- Provide a dark code editor theme
					- (sqlDashboards) Fix heatmap to support single string columns again
					
2014-09-01 - 1.34	- Added Server Tree options to allow cloning connectsion, renaming folders, etc.
					- Bugfixes to server edit screen, autocomplete and jump-to-definition

2014-04-18 - 1.33	- Allow renaming folders and adding connections to folders.
					- Bugfix editing connectioning dialog was changing port to default
					- Bugfix more careful returning connections to connection pool
					- (sqlDashboards) Add SqlChart command line charting application.
					  
2014-03-13 - 1.32	- (sqlDashboards) Candlestick chart - has separate charts for volume and prices.
					- (sqlDashboards) Add live yahoo finance sqlDashboards demos for built-in database and kdb+
					- (sqlDashboards) Command Line Chart Generator added.
					- (sqlDashboards) Major change to how dashboard arguments are formed.

2014-03-01 - 1.31	- minor bugfix release.  

2014-02-11 - 1.30	- Ctrl-P power bar that allows performing most actions from the editor
						e.g. lookup docs, open file, switch server. Also Ctrl-I,Ctrl-U
					- Many many Changes to sqlDashboards, including forms...
					- Scrolling line numbers on result table (Thanks Ankit)
					- Configurable Server Connection Querying, (Thanks Sunny)
						settings for persist connection, wrap queries etc.
					- Allow code editor font selection (Thanks Jean-Pierre)
					- Ability to place servers in folders.
					- Servers can have a color set that will alter the editor background.
					
					
2013-11-11 - 1.29   - Added Chart Themes including dark bbg
					- Allowed multiple instances of qStudio
					
2013-06-27 - 1.28   - Added Csv Loader (pro)
					- Added qUnit unit testing (pro)
					- Bugfix to database management column copying.
					- Export selection/table bugs fixed and launches excel (thanks Jeremy / Ken)
					
2013-05-06 - 1.27   - Support charting and formatted text for all Kdb Time types including Timespan, Timestamp, Month etc.
					- Sorting columns by numeric columns now sorts numerically (thanks Ken)
					- Added more q keywords and documentation
					- Many small bug fixes (thanks Seetaram)

2013-03-25 - 1.26   - Add File Tree that allows browsing directory and providing autocomplete
					- qDoc supports custom user tags (Thanks Aaron)
					- Allow adding/exporting whole lists of servers at once (much quicker)
					- Installers are now signed.
					- Ctrl-D "goto definition" of function to open that file/position
					- (PRO) Unit Testing and function profiling partially integrated.
					
2013-01-30 - 1.25   - Faster chart drawing (~1.6x faster)
					- Added No Redraw chart option for those who want extra speed
					- Numerous bugfixes to charts that froze
					- Allow setting code editor font size
					- Fix display of boolean/byte lists

2013-01-30 - 1.23   - Added Tree view of list data.
					- Quicker drawing of large complex objects.
					- Crash asks user to report from in-app.
					- BugFix: Tooltips for tables with many columns caused Aero crash (thanks Sunny)
					- BugFix: Secured servers where populating tree throws exceptions
					
2013-01-25 - 1.21   - Mac UI Improvements (thanks Charlie)
					
2013-01-24 - 1.20   - Results Table shows wide tables with scrollbar (thanks Weiyi)
					